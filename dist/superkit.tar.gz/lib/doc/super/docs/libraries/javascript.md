---
weight: 2
title: JavaScript
---

The [zed-js library](https://github.com/brimdata/zui/tree/main/packages/zed-js)
provides support for the Zed data model from within
JavaScript as well as methods for communicating with a Zed lake.

Because JavaScript's native type system is limtied, zed-js provides
implementations for each of Zed's primitive types as well as
technique for interpreting and/or constructing arbitrary complex types.

## Installation

Documentation coming soon.

## Library API

Documentation coming soon.

## Examples

Examples coming soon.
