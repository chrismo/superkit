---
title: Libraries
weight: 7
---

Zed currently supports a small number of languages
with client libraries for manipulating Zed data and interacting
with a Zed service via the remote API.

Our documentation for client libraries is early but will
be improved as the project develops.

We plan to support a broad range of languages.  Open source contributions
are welcome.  Give us a holler on [Slack](https://www.brimdata.io/join-slack/)
if you would like help or guidance on developing a Zed library.
