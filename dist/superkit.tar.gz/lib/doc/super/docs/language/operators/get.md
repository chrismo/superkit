### Operator

&emsp; **get** &mdash; source data from a URI

### Synopsis

`get` is a shorthand notation for `from`. See the [`from` operator](from.md) documentation for details.
