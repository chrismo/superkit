### Function

&emsp; **missing** &mdash; test for the "missing" error

### Synopsis

```
missing(val: any) -> bool
```

### Description

The _missing_ function returns true if its argument is `error("missing")`
and false otherwise.

This function is often used to test if certain fields do not appear as
expected in a record, e.g., `missing(a)` is true either when `this` is not a record
or when `this` is a record and the field `a` is not present in `this`.

It's also useful in shaping when applying conditional logic based on the
absence of certain fields:
```
switch (
  case missing(a) => ...
  case missing(b) => ...
  default => ...
)
```

### Examples

```mdtest-spq
# spq
yield {yes:missing(bar),no:missing(foo)}
# input
{foo:10}
# expected output
{yes:true,no:false}
```

```mdtest-spq
# spq
yield {yes:has(foo[3]),no:has(foo[0])}
# input
{foo:[1,2,3]}
# expected output
{yes:false,no:true}
```

```mdtest-spq
# spq
yield {yes:missing(foo.baz),no:missing(foo.bar)}
# input
{foo:{bar:"value"}}
# expected output
{yes:true,no:false}
```

```mdtest-spq
# spq
yield {yes:missing(bar+1),no:missing(foo+1)}
# input
{foo:10}
# expected output
{yes:true,no:false}
```

```mdtest-spq
# spq
yield missing(bar)
# input
1
# expected output
true
```

```mdtest-spq
# spq
yield missing(x)
# input
{x:error("missing")}
# expected output
true
```
