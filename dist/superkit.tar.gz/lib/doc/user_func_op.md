user-defined ops can call other user-defined ops and funcs user-defined funcs
can only call other funcs(?)

_I think I saw an example somewhere that what I could've sworn called built-in
ops_
